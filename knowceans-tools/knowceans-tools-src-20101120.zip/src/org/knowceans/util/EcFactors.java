package org.knowceans.util;

import java.math.*;
import java.security.SecureRandom;

/**
 * Uses elliptic curves to factor a large integer.
 * <p>
 * Code is a version of Dario Alpern's ECM algorithm:
 * http://www.alpertron.com.ar/ECM.HTM
 * 
 * 
 */
public class EcFactors {

    // Parameters for elliptic curve
    private BigInteger n;
    private BigInteger a24;

    /**
     * Montgomery coordinates and manipulation
     * 
     * @author gregor
     * 
     */
    private class MPoint {
        // Instance Variables
        public BigInteger x;
        public BigInteger z;

        /**
         * constructs a Montgomery point for factoring n with a24 (from
         * containing class)
         * 
         * @param x
         * @param z
         */
        public MPoint(BigInteger x, BigInteger z) {
            this.x = x;
            this.z = z;
        }

        // toString
        public String toString() {
            return ("(" + x + " : " + z + ")");
        }

        // Multiplication of a Scalar and Montgomery Coordinate (X : Z) on
        // Elliptic
        // Curve (Montgomery Ladder Algorithm)
        public MPoint scale(BigInteger k) {
            String kString = k.toString(2);
            int s = kString.length();
            MPoint Q = this;
            MPoint R = twice();

            for (int i = 1; i < s; i++) {
                if (kString.charAt(i) == '1') {
                    Q = R.add(Q, this);
                    R = R.twice();
                } else {
                    R = Q.add(R, this);
                    Q = Q.twice();
                }
            }

            return Q;
        }

        // Addition Of Montgomery Coordinates (X : Z) On Elliptic Curve
        public MPoint add(MPoint q, MPoint r) {
            BigInteger u = this.x.subtract(this.z).multiply(q.x.add(q.z));
            BigInteger v = this.x.add(this.z).multiply(q.x.subtract(q.z));
            BigInteger upv = u.add(v);
            BigInteger umv = u.subtract(v);
            BigInteger x = r.z.multiply(upv.multiply(upv)).mod(n);
            BigInteger z = r.x.multiply(umv.multiply(umv)).mod(n);
            return (new MPoint(x, z));
        }

        // Doubling Of Montgomery Coordinates (X : Z) On Elliptic Curve
        public MPoint twice() {
            BigInteger u = this.x.add(this.z);
            BigInteger v = this.x.subtract(this.z);
            BigInteger u2 = u.multiply(u);
            BigInteger v2 = v.multiply(v);
            BigInteger t = u2.subtract(v2);
            BigInteger x = u2.multiply(v2).mod(n);
            BigInteger z = t.multiply(v2.add(a24.multiply(t))).mod(n);
            return (new MPoint(x, z));
        }
    }

    public static final BigInteger ONE = BigInteger.valueOf(1);
    public static final BigInteger TWO = BigInteger.valueOf(2);
    public static final BigInteger THREE = BigInteger.valueOf(3);
    public static final BigInteger FOUR = BigInteger.valueOf(4);
    public static final BigInteger FIVE = BigInteger.valueOf(5);

    public BigInteger factor(BigInteger n) {
        BigInteger g = ONE;

        // Choose Bounds
        double _q = Math.pow(10, (n.toString().length() - 2) / 2);
        int B1 = (int) Math.ceil(Math.exp(Math.sqrt(0.5 * Math.log(_q)
                * Math.log(Math.log(_q)))) / 10) * 10;
        int B2 = B1 * 100;
        int D = (int) Math.sqrt(B2);
        System.out.println("Smoothness Bounds: " + B1);

        // Phase 1 Precomputations - Prime Ladder
        System.out.println("Phase 1 Precomputations..");
        double logB1 = Math.log10(B1);
        boolean[] composites = new boolean[B1];
        BigInteger k = ONE;
        for (int i = 2; i < B1; i++) {
            if (!composites[i]) {
                k = k.multiply(BigInteger.valueOf((long) Math.pow(i, (int) Math
                        .floor(logB1 / Math.log10(i)))));
                for (int j = i + i; j < B1; j += i) {
                    composites[j] = true;
                }
            }
        }
        composites = null;
        System.gc();

        // Phase 2 Precomputations
        System.out.println("Phase 2 Precomputations..");
        int[] qPrimes = Primes.primes(B1 + 1, B2);
        int totalPrimes = qPrimes.length;
        MPoint[] S = new MPoint[D + 1];
        BigInteger[] Beta = new BigInteger[D + 1];

        // Phase 1
        int curves = 0;
        while (g.equals(ONE) || g.equals(n)) {
            // Generate 32 Bit Sigma
            BigInteger sigma = new BigInteger(32, new SecureRandom());

            // Calculate Curve Parameters u, v, A From Sigma
            // u = (sigma^2 - 5) % n
            BigInteger u = sigma.pow(2).subtract(FIVE).mod(n);
            // v = (4 * sigma) mod n
            BigInteger v = FOUR.multiply(sigma).mod(n);
            // A = ((v - u)^3 (3u + v) / (4u^2 v) - 2) mod n
            BigInteger A = (v.subtract(u).pow(3).multiply(
                THREE.multiply(u).add(v)).divide(
                FOUR.multiply(u.pow(3)).multiply(v)).subtract(TWO)).mod(n);
            a24 = A.add(TWO).divide(FOUR);

            // Calculate Point P On Curve
            MPoint P = new MPoint(u.pow(3).divide(v.pow(3)).mod(n), ONE);
            // MontgomeryCoord P = new MontgomeryCoord(u.modPow(BigMath.THREE,
            // n), v.modPow(BigMath.THREE, n));
            System.out.println("Curve " + ++curves + ": " + sigma);

            // Scalar Multiplication
            MPoint Q = P.scale(k);
            g = n.gcd(Q.z);

            // Phase 2
            if (g.equals(ONE) || g.equals(n)) {
                S[1] = Q.twice();
                S[2] = S[1].twice();

                for (int d = 1; d <= D; d++) {
                    if (d > 2) {
                        S[d] = S[d - 1].add(S[1], S[d - 2]);
                    }
                    Beta[d] = S[d].x.multiply(S[d].z).mod(n);
                }

                g = ONE;
                int B = B1 - 1;
                MPoint T = Q.scale(BigInteger.valueOf((long) (B - 2 * D)));
                MPoint R = Q.scale(BigInteger.valueOf((long) B));
                BigInteger alpha;
                int delta;
                MPoint tmpR;

                int q = 0;
                for (int r = B; r < B2; r = r + 2 * D) {
                    alpha = R.x.multiply(R.z).mod(n);

                    int limit = r + 2 * D;
                    while (qPrimes[q] <= limit && q < totalPrimes) {
                        delta = (qPrimes[q] - r) / 2;
                        g = g.multiply(
                            R.x.subtract(S[delta].x).multiply(
                                R.z.add(S[delta].z)).subtract(alpha).add(
                                Beta[delta])).mod(n);
                        q++;
                    }
                    tmpR = R;
                    R = R.add(S[D], T);
                    T = tmpR;
                }
                g = n.gcd(g);
            }
        }
        return g;
    }
}
