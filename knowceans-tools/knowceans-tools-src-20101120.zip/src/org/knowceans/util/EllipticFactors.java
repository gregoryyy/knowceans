package org.knowceans.util;

import java.math.BigInteger;

import org.knowceans.util.Samplers;

/**
 * find prime factor using elliptic curves
 * <p>
 * This copies code from:
 * 
 * @author gregor
 * 
 */
public class EllipticFactors {

    public static long factor(long n) {
        long g = 1l;

        // Choose Bounds
        // double _q = Math.pow(10, (n.toString().length() - 2) / 2);
        double _q = Math.pow(10, (Math.log10(n) - 2) / 2);
        int b1 = (int) Math.ceil(Math.exp(Math.sqrt(0.5 * Math.log(_q)
                * Math.log(Math.log(_q)))) / 10) * 10;
        int B2 = b1 * 100;
        int d = (int) Math.sqrt(B2);
        System.out.println("Smoothness Bounds: " + b1);

        // prime ladder
        System.out.println("Phase 1 Precomputations..");
        double logB1 = Math.log10(b1);
        boolean[] composites = new boolean[b1];
        long k = 1l;
        for (int i = 2; i < b1; i++) {
            if (!composites[i]) {
                k *= Math.pow(i, (int) Math.floor(logB1 / Math.log10(i)));
                for (int j = i + i; j < b1; j += i) {
                    composites[j] = true;
                }
            }
        }
        composites = null;
        System.gc();

        // Phase 2 Precomputations
        System.out.println("Phase 2 Precomputations..");
        // primeSiever = new PrimeSiever()
        // int[] qPrimes = primeSiever.sieve(b1 + 1, B2);
        // int totalPrimes = primeSiever.totalPrimes;

        int[] qprimes = Primes.primes(b1 + 1, B2);
        int nprimes = qprimes.length;
        long[][] ss = new long[d + 1][2];
        long[] beta = new long[d + 1];

        int curves = 0;
        while (g == 1 || g == n) {
            // sigma 32 random value
            long sigma = Samplers.randUniform(Integer.MAX_VALUE);

            // curve coefficients
            long u = (sigma * sigma - 5) % n;
            long v = (4 * sigma) % n;
            long w = (v - u);
            // A = ((v - u)^3 (3u + v) / (4u^2 v) - 2) mod n
            long A = (w * w * w * (3 * u - v) / (4 * u * u * v - 2)) % n;
            double a24 = (A + 2) / 4;

            // point p on curve
            long[] pp = new long[2];
            pp[0] = (u * u * u / v * v * v) % n;
            pp[1] = 1l;
            System.out.println("Curve " + ++curves + ": " + sigma);

            long[] qq = scale(k, pp, n, a24);
            g = Primes.gcd(n, qq[1]);

            if (g == 1 || g == n) {
                ss[1] = twice(qq, n, a24);
                ss[2] = twice(ss[1], n, a24);

                for (int i = 1; i <= d; i++) {
                    if (i > 2) {
                        ss[i] = add(ss[i - 1], ss[1], ss[i - 2], n);
                    }
                    beta[i] = ss[i][0] * ss[i][1] % n;
                }

                g = 1l;
                int b = b1 - 1;
                long[] tt = scale(b - 2 * d, qq, n, a24);
                long[] rr = scale(b, qq, n, a24);
                long[] rr0;
                int q = 0;
                long alpha;
                int di;
                for (int i = b; i < B2; i = i + 2 * d) {
                    alpha = (rr[0] * rr[1]) % n;

                    int limit = i + 2 * d;
                    while (qprimes[q] <= limit && q < nprimes) {
                        di = (qprimes[q] - i) / 2;
                        g = ((g * rr[0] - ss[di][0]) * (rr[1] + ss[di][1])
                                - alpha + beta[di])
                                % n;

                        q++;
                    }
                    rr0 = rr;
                    rr = add(rr, ss[d], tt, n);
                    tt = rr0;
                }

                g = Primes.gcd(n, g);
            }
        }
        return g;
    }

    /**
     * double point p in Montgomery coords on curve
     * 
     * @param p
     * @return
     */
    public static long[] twice(long[] p, long n, double a24) {
        long u = p[0] + p[1];
        long v = p[0] - p[1];
        long u2 = u * u;
        long v2 = v * v;
        long t = u2 - v2;
        long x = u2 * v2 % n;
        long z = (long) ((t * (v2 + a24 * t)) % n);
        return (new long[] { x, z });
    }

    /**
     * scale point p on curve (Montgomery ladder)
     */
    public static long[] scale(long a, long[] p, long n, double a24) {
        // int s = (int) (Math.log(k) / Math.log(2));
        BigInteger kk = BigInteger.valueOf(a);
        String kString = kk.toString(2);
        int s = kString.length();
        long[] qq = new long[] { p[0], p[1] };
        long[] rr = twice(p, n, a24);

        for (int i = 1; i < s; i++) {
            if (kString.charAt(i) == '1') {
                qq = add(rr, qq, p, n);
                rr = twice(rr, n, a24);
            } else {
                rr = add(qq, rr, p, n);
                qq = twice(qq, n, a24);
            }
        }

        return qq;
    }

    /**
     * add p + q in Montgomery coords (x, z) on curve
     */
    public static long[] add(long[] p, long[] q, long[] r, long n) {
        long u = (p[0] - p[1]) * (q[0] + q[1]);
        long v = (p[0] + p[1]) * (q[0] - q[1]);
        long upv = u + v;
        long umv = u - v;
        long x = r[1] * upv * upv % n;
        long z = r[0] * umv * umv % n;
        return (new long[] { x, z });
    }

    public static void main(String[] args) {
        long a = factor(67676767676167111l);
        while (a > 1) {
            System.out.println(a);
            a = factor(a);
        }
        System.out.println(a);
    }
}
