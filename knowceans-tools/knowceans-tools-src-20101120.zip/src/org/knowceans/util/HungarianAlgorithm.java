package org.knowceans.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Implements the Hungarian algorithm by Kuhn (1955) based on a cost function
 * provided in the abstract method cost. Formally, given a The optimisation
 * problem is:
 * 
 * @author Gregor Heinrich (Java 5+ and adaptation)
 * @author Tom Nye (original algorithm implementation) http://www.mas.ncl.ac.
 *         uk/~ntmwn/phylo_comparison/MunkresAlgorithm.java
 * 
 * @param <Row>
 *            row type
 * @param <Col>
 *            column type
 */
// FIXME: stack overflow
public class HungarianAlgorithm<Row, Col> {

    public static final double EPS = 1.e-12;

    /**
     * determines the cost of assigning a to b.
     * 
     * @param a
     * @param b
     * @return
     */
    // public abstract double cost(Row a, Col b);

    /**
     * rows covered
     */
    private Set<Row> rcov;
    /**
     * cols covered
     */
    private Set<Col> ccov;
    /**
     * zstar rows
     */
    private Map<Col, Row> zsc2r;
    /**
     * zstart cols
     */
    private Map<Row, Col> zsr2c;
    /**
     * optimal solution
     */
    private Map<Row, Col> optmap;
    /**
     * z prime cols
     */
    private Map<Row, Col> zpr2c;

    /**
     * init fields
     */
    public HungarianAlgorithm() {
        ccov = new HashSet<Col>();
        rcov = new HashSet<Row>();
        zsr2c = new HashMap<Row, Col>();
        zsc2r = new HashMap<Col, Row>();
        zpr2c = new HashMap<Row, Col>();
    }

    /**
     * Run Hungarian algorithm
     * 
     * @param rows
     * @param cols
     * @param scores
     * @param initmap
     *            initial assignment
     * @throws IllegalArgumentException
     */
    public void run(HashSet<Row> rows, HashSet<Col> cols,
            HashMap<String, Double> scores, HashMap<Row, Col> initmap)
            throws IllegalArgumentException {
        if (cols.size() < rows.size())
            throw new IllegalArgumentException("ncols < nrows");

        optmap = initmap;
        // Find minimum in each column and subtract from that column.
        colMinusMin(rows, cols, scores);
        // initial z* set
        zstarInit(rows, cols, scores);
        int nccov = 0;
        for (Col col : cols) {
            if (zsc2r.containsKey(col)) {
                nccov++;
                ccov.add(col);
            }
        }
        // complete?
        if (nccov == rows.size()) {
            buildOptimum(rows);
            return;
        }

        zsearch(rows, cols, scores);

        boolean done = true;
        for (Col col : ccov) {
            if (!zsc2r.containsKey(col))
                done = false;
        }

        if (!done)
            throw new IllegalArgumentException(
                    "Algorithm Error following main zero search in Munkres algorithm");

        buildOptimum(rows);
        return;
    }

    /**
     * get the hash string corresponding to two objects -- used to reference
     * scores
     */
    public static <Row, Col> String hash(Row a, Col b) {
        return a.hashCode() + "+" + b.hashCode();
    }

    /**
     * add const to a row
     */
    public void rowPlusConst(double value, Row row, HashSet<Col> cols,
            HashMap<String, Double> scores) {
        for (Col col : cols) {
            String hashRef = hash(row, col);
            double x = scores.get(hashRef) + value;
            scores.put(hashRef, new Double(x));
        }
    }

    /**
     * add const to a col
     */
    public void colPlusConst(double value, Col col, HashSet<Row> rows,
            HashMap<String, Double> scores) {
        for (Row row : rows) {
            String hashRef = hash(row, col);
            double x = scores.get(hashRef) + value;
            scores.put(hashRef, new Double(x));
        }
    }

    /**
     * Subtract the minimum of each column from the whole column
     */
    private void colMinusMin(HashSet<Row> rows, HashSet<Col> cols,
            HashMap<String, Double> scores) {
        for (Col col : cols) {
            double colmin = Double.NaN;
            for (Row row : rows) {
                double x = scores.get(hash(row, col));
                if (colmin == Double.NaN) {
                    colmin = x;
                } else {
                    if (x < colmin)
                        colmin = x;
                }

            }
            colmin = -colmin;
            colPlusConst(colmin, col, rows, scores);
        }
    }

    /**
     * is double considered zero?
     */
    private boolean isZero(Double d) {
        return Math.abs(d) < EPS;
    }

    /**
     * find an initial set Z*
     */
    public void zstarInit(HashSet<Row> rows, HashSet<Col> cols,
            HashMap<String, Double> scores) throws IllegalArgumentException {
        for (Col col : cols) {
            for (Row row : rows) {
                double d = scores.get(hash(row, col));
                if (isZero(d)) {
                    if ((!zsr2c.containsKey(row)) && (!zsc2r.containsKey(col))) {
                        zsr2c.put(row, col);
                        zsc2r.put(col, row);
                    }
                }
            }
        }
    }

    /**
     * assess optimality
     */
    public void assess(HashSet<Row> rows, HashSet<Col> cols,
            HashMap<String, Double> scores) throws IllegalArgumentException {
        // cover every col containing a z*
        for (Col col : cols) {
            if (zsc2r.containsKey(col))
                ccov.add(col);
        }
        // <- this was for a square solution
        // if (ccov.containsAll(cols)) return;
        if (ccov.size() == rows.size())
            return;
        else
            zsearch(rows, cols, scores);
    }

    /**
     * build optimum solution
     */
    public void buildOptimum(HashSet<Row> rows) {
        for (Row row : rows) {
            Col col = zsr2c.get(row);
            optmap.put(row, col);
        }
    }

    /**
     * main zero search
     */
    public void zsearch(HashSet<Row> rows, HashSet<Col> cols,
            HashMap<String, Double> scores) throws IllegalArgumentException {
        boolean haszeros = true;

        while (haszeros) {
            haszeros = false;

            HashSet<Row> runcov = new HashSet<Row>();
            runcov.addAll(rows);
            runcov.removeAll(rcov);
            HashSet<Col> cuncov = new HashSet<Col>();
            cuncov.addAll(cols);
            cuncov.removeAll(ccov);

            // find an uncovered zero
            for (Col col : cuncov) {
                for (Row row : runcov) {
                    double d = scores.get(hash(row, col));
                    if (isZero(d)) {
                        zpr2c.put(row, col);
                        if (!zsr2c.containsKey(row)) {
                            incrementStarredZeros(row, col, rows, cols, scores);
                            return;
                        } else {
                            Object starCol = zsr2c.get(row);
                            if (ccov.contains(starCol))
                                ccov.remove(starCol);
                            rcov.add(row);
                            haszeros = true;
                            break;
                        }
                    }
                }
            }
        }
        newZeros(rows, cols, scores);
    }

    /**
     * increment set of starred zeros
     */
    public void incrementStarredZeros(Row row, Col col, HashSet<Row> rows,
            HashSet<Col> cols, HashMap<String, Double> scores)
            throws IllegalArgumentException {
        // Construct the alternating sequence of primed and starred zeros
        // row of primed zeros
        ArrayList<Row> zrows = new ArrayList<Row>();

        zrows.add(row);

        boolean done = false;
        while (!done) {
            if (!zsc2r.containsKey(col))
                done = true;
            else {
                row = zsc2r.get(col);
                if (zpr2c.containsKey(row)) {
                    zrows.add(row);
                    col = zpr2c.get(row);
                } else {
                    done = true;
                }
            }
        }

        // unstar each starred zero of the sequence
        int end = zrows.size() - 1;
        for (Row zrow : zrows) {
            col = zsr2c.get(zrow);
            zsc2r.remove(col);
            zsr2c.remove(zrow);
            // loop until < size - 1
            if (--end == 0)
                break;
        }
        // Star each primed zero in the sequence
        for (Row zrow : zrows) {
            col = zpr2c.get(zrow);
            zsc2r.put(col, zrow);
            zsr2c.put(zrow, col);
        }
        // Erase all primes; uncover all cols and rows
        ccov.clear();
        rcov.clear();
        zpr2c.clear();

        assess(rows, cols, scores);
    }

    /** New zero manufactures */
    public void newZeros(HashSet<Row> rows, HashSet<Col> cols,
            HashMap<String, Double> scores) throws IllegalArgumentException {
        // Find the smallest uncovered score
        boolean started = false;
        double minVal = 0.0;
        HashSet<Row> runcover = new HashSet<Row>();
        runcover.addAll(rows);
        runcover.removeAll(rcov);
        HashSet<Col> cuncover = new HashSet<Col>();
        cuncover.addAll(cols);
        cuncover.removeAll(ccov);
        for (Col col : cuncover) {
            for (Row row : runcover) {
                if (!started) {
                    started = true;
                    minVal = ((Double) scores.get(hash(row, col)))
                            .doubleValue();
                } else {
                    double x = ((Double) scores.get(hash(row, col)))
                            .doubleValue();
                    if (x < minVal)
                        minVal = x;
                }
            }
        }

        // Add minVal to all covered rows
        double h = minVal;
        for (Row row : rcov) {
            rowPlusConst(h, row, cols, scores);
        }

        // Subtract minVal from all uncovered columns
        h = -minVal;
        for (Col col : cuncover) {
            colPlusConst(h, col, rows, scores);
        }

        zsearch(rows, cols, scores);
    }

    // Unit test
    public static void main(String[] args) throws IllegalArgumentException {

        String x = "X";
        String y = "Y";
        HashSet<String> rows = new HashSet<String>();
        rows.add(x);
        rows.add(y);

        String a = "A";
        String b = "B";
        String c = "C";
        String d = "D";
        HashSet<String> cols = new HashSet<String>();
        cols.add(a);
        cols.add(b);
        cols.add(c);
        cols.add(d);

        HashMap<String, Double> scores = new HashMap<String, Double>();
        // TODO: this should be done with a cost method
        scores.put(hash(x, a), new Double(1));
        scores.put(hash(x, b), new Double(4));
        scores.put(hash(x, c), new Double(5));
        scores.put(hash(x, d), new Double(3));
        scores.put(hash(y, a), new Double(5));
        scores.put(hash(y, b), new Double(10));
        scores.put(hash(y, c), new Double(6));
        scores.put(hash(y, d), new Double(3));

        HashMap<String, String> assignment = new HashMap<String, String>();
        HungarianAlgorithm<String, String> algo = new HungarianAlgorithm<String, String>();
        algo.run(rows, cols, scores, assignment);

        for (String s : rows) {
            String t = (String) assignment.get(s);
            System.out.println(s + " -> " + t);
        }

        System.exit(0);
    }

}
