package org.knowceans.util;

/*
 * MunkresAlgorithm.java
 *
 * Created on 09 May 2005, 16:23
 *
 * @author  thomas
 */

/**
 * Perform the Munkres assignment algorithm.
 *
 * See: http://www.netlib.org/utk/lsi/pcwLSI/text/node220.html
 *
 * Refs:
 *  Kuhn, H. W. ``The Hungarian method for the assignment problem,'' Naval Research Logistics Quarterly, 2:83, 1955.
 *  Burgeios, F., and Lassalle, J. C. ``An extension of munkres algorithm for the assignment problem to rectangular matrices,'' Comm. of the ACM, 14:802, 1971.
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class HungarianAlgorithmOrig {

    // Instance variables
    private HashSet coveredCols;
    private HashSet coveredRows;
    private HashMap zStarCol;
    private HashMap zStarRow;
    private HashMap zPrimeCol;
    private HashMap solution;

    /** Constructor */
    public HungarianAlgorithmOrig() {
        coveredCols = new HashSet();
        coveredRows = new HashSet();
        zStarCol = new HashMap();
        zStarRow = new HashMap();
        zPrimeCol = new HashMap();
    }

    /**
     * Perform the Munkres assignment algorithm We match elements in A and B to
     * minimise the overall dissimilarity score
     */
    public void Solve(HashSet rowList, HashSet colList, HashMap scores,
            HashMap assignment) throws IllegalArgumentException {
        if (colList.size() < rowList.size())
            throw new IllegalArgumentException(
                    "Size mis-match in Munkres algorithm.");

        // Initialize
        solution = assignment; // Make the assignment matrix accessible globally
        // Find minimum in each column and subtract from that column.
        subtractColMin(rowList, colList, scores);
        // Get an initial z* set
        setUp(rowList, colList, scores);
        // Assess for solution
        int nColsCovered = 0;
        Iterator colIt = colList.iterator();
        for (int i = 0; i < colList.size(); i++) {
            Object theCol = colIt.next();
            if (zStarRow.containsKey(theCol)) {
                nColsCovered++;
                coveredCols.add(theCol);
            }
        }

        if (nColsCovered == rowList.size()) {
            buildSolution(rowList);
            return;
        }

        mainZeroSearch(rowList, colList, scores);

        colIt = coveredCols.iterator();
        boolean done = true;
        for (int i = 0; i < coveredCols.size(); i++) {
            Object theCol = colIt.next();
            if (!zStarRow.containsKey(theCol))
                done = false;
        }

        if (!done)
            throw new IllegalArgumentException(
                    "Algorithm Error following main zero search in Munkres algorithm");

        buildSolution(rowList);
        return;
    }

    /**
     * Get the hash string corresponding to two objects -- used to reference
     * scores
     */
    static public String getHashString(Object a, Object b) {
        int i = a.hashCode();
        int j = b.hashCode();
        String s = (new Integer(i)).toString();
        s += "+";
        s += (new Integer(j)).toString();
        return s;
    }

    /** Add const to a row */
    public void addToRow(double value, Object theRow, HashSet colList,
            HashMap scores) {
        Iterator it = colList.iterator();
        for (int i = 0; i < colList.size(); i++) {
            Object theCol = it.next();
            String hashRef = getHashString(theRow, theCol);
            Double d = (Double) scores.get(hashRef);
            double x = d.doubleValue() + value;
            scores.put(hashRef, new Double(x));
        }
    }

    /** Add const to a col */
    public void addToCol(double value, Object theCol, HashSet rowList,
            HashMap scores) {
        Iterator it = rowList.iterator();
        for (int i = 0; i < rowList.size(); i++) {
            Object theRow = it.next();
            String hashRef = getHashString(theRow, theCol);
            Double d = (Double) scores.get(hashRef);
            double x = d.doubleValue() + value;
            scores.put(hashRef, new Double(x));
        }
    }

    /** Subtract the minimum of each column from the whole column */
    private void subtractColMin(HashSet rowList, HashSet colList, HashMap scores) {
        Iterator colIt;
        Iterator rowIt;
        Object theCol;
        Object theRow;
        colIt = colList.iterator();
        for (int j = 0; j < colList.size(); j++) {
            theCol = colIt.next();
            rowIt = rowList.iterator();
            theRow = rowIt.next();
            double colmin = ((Double) scores.get(getHashString(theRow, theCol)))
                    .doubleValue();
            for (int i = 1; i < rowList.size(); i++) {
                theRow = rowIt.next();
                double x = ((Double) scores.get(getHashString(theRow, theCol)))
                        .doubleValue();
                if (x < colmin)
                    colmin = x;
            }
            colmin = -colmin;
            addToCol(colmin, theCol, rowList, scores);
        }
    }

    /** Test whether a Double is zero */
    private boolean isZero(Double d) {
        double x = d.doubleValue();
        if (Math.abs(x) < 1E-12)
            return true;
        else
            return false;
    }

    /** Find an initial set Z* */
    public void setUp(HashSet rowList, HashSet colList, HashMap scores)
            throws IllegalArgumentException {
        Iterator colIt;
        Iterator rowIt;
        Object theCol;
        Object theRow;
        colIt = colList.iterator();
        for (int j = 0; j < colList.size(); j++) {
            theCol = colIt.next();
            rowIt = rowList.iterator();
            for (int i = 0; i < rowList.size(); i++) {
                theRow = rowIt.next();
                Double d = (Double) scores.get(getHashString(theRow, theCol));
                if (isZero(d)) {
                    if ((!zStarCol.containsKey(theRow))
                            && (!zStarRow.containsKey(theCol))) {
                        zStarCol.put(theRow, theCol);
                        zStarRow.put(theCol, theRow);
                    }
                }
            }
        }
    }

    /** Solution assessment */
    public void solutionAssessment(HashSet rowList, HashSet colList,
            HashMap scores) throws IllegalArgumentException {
        // Cover every col containing a z*
        Iterator colIt;
        Object theCol;
        colIt = colList.iterator();
        for (int j = 0; j < colList.size(); j++) {
            theCol = colIt.next();
            if (zStarRow.containsKey(theCol))
                coveredCols.add(theCol);
        }
        // if (coveredCols.containsAll(colList)) return; // <- this was for a
        // square solution
        if (coveredCols.size() == rowList.size())
            return;
        else
            mainZeroSearch(rowList, colList, scores);
    }

    /** Build the solution */
    public void buildSolution(HashSet rowList) {
        Iterator rowIt = rowList.iterator();
        Object theRow;
        for (int i = 0; i < rowList.size(); i++) {
            theRow = rowIt.next();
            Object theCol = zStarCol.get(theRow);
            solution.put(theRow, theCol);
        }
    }

    /** Main zero search */
    public void mainZeroSearch(HashSet rowList, HashSet colList, HashMap scores)
            throws IllegalArgumentException {
        boolean zerosFound = true;

        while (zerosFound) {
            zerosFound = false;

            HashSet uncoveredRows = new HashSet();
            uncoveredRows.addAll(rowList);
            uncoveredRows.removeAll(coveredRows);
            HashSet uncoveredCols = new HashSet();
            uncoveredCols.addAll(colList);
            uncoveredCols.removeAll(coveredCols);

            // Find an uncovered zero
            Iterator colIt = uncoveredCols.iterator();
            for (int j = 0; j < uncoveredCols.size(); j++) {
                Object theCol = colIt.next();
                Iterator rowIt = uncoveredRows.iterator();
                for (int i = 0; i < uncoveredRows.size(); i++) {
                    Object theRow = rowIt.next();
                    Double d = (Double) scores
                            .get(getHashString(theRow, theCol));
                    if (isZero(d)) {
                        zPrimeCol.put(theRow, theCol);
                        if (!zStarCol.containsKey(theRow)) {
                            incrementStarredZeros(theRow, theCol, rowList,
                                colList, scores);
                            return;
                        } else {
                            Object starCol = zStarCol.get(theRow);
                            if (coveredCols.contains(starCol))
                                coveredCols.remove(starCol);
                            coveredRows.add(theRow);
                            zerosFound = true;
                            break; // Go on to next column
                        }
                    }
                }
            }
        } // End looking for zeros

        makeNewZeros(rowList, colList, scores);

    }

    /** Increment set of starred zeros */
    public void incrementStarredZeros(Object theRow, Object theCol,
            HashSet rowList, HashSet colList, HashMap scores)
            throws IllegalArgumentException {
        // Construct the alternating sequence of primed and starred zeros
        ArrayList zRow = new ArrayList(); // Store the row of primed zeros

        zRow.add(theRow);

        boolean done = false;
        while (!done) {
            if (!zStarRow.containsKey(theCol))
                done = true;
            else {
                theRow = zStarRow.get(theCol);
                if (zPrimeCol.containsKey(theRow)) {
                    zRow.add(theRow);
                    theCol = zPrimeCol.get(theRow);
                } else {
                    done = true;
                }
            }
        }

        // Unstar each starred zero of the sequence
        Iterator rowIt = zRow.iterator();
        for (int i = 0; i < zRow.size() - 1; i++) {
            theRow = rowIt.next();
            theCol = zStarCol.get(theRow);
            zStarRow.remove(theCol);
            zStarCol.remove(theRow);
        }
        // Star each primed zero in the sequence
        rowIt = zRow.iterator();
        for (int i = 0; i < zRow.size(); i++) {
            theRow = rowIt.next();
            theCol = zPrimeCol.get(theRow);
            zStarRow.put(theCol, theRow);
            zStarCol.put(theRow, theCol);
        }
        // Erase all primes; uncover all cols and rows
        coveredCols.clear();
        coveredRows.clear();
        zPrimeCol.clear();

        solutionAssessment(rowList, colList, scores);
    }

    /** New zero manufactures */
    public void makeNewZeros(HashSet rowList, HashSet colList, HashMap scores)
            throws IllegalArgumentException {
        // Find the smallest uncovered score
        boolean started = false;
        double minVal = 0.0;
        HashSet uncoveredRows = new HashSet();
        uncoveredRows.addAll(rowList);
        uncoveredRows.removeAll(coveredRows);
        HashSet uncoveredCols = new HashSet();
        uncoveredCols.addAll(colList);
        uncoveredCols.removeAll(coveredCols);
        Iterator colIt = uncoveredCols.iterator();
        for (int j = 0; j < uncoveredCols.size(); j++) {
            Object theCol = colIt.next();
            Iterator rowIt = uncoveredRows.iterator();
            for (int i = 0; i < uncoveredRows.size(); i++) {
                Object theRow = rowIt.next();
                if (!started) {
                    started = true;
                    minVal = ((Double) scores
                            .get(getHashString(theRow, theCol))).doubleValue();
                } else {
                    double x = ((Double) scores.get(getHashString(theRow,
                        theCol))).doubleValue();
                    if (x < minVal)
                        minVal = x;
                }
            }
        }

        // Add minVal to all covered rows
        double h = minVal;
        Iterator rowIt = coveredRows.iterator();
        for (int i = 0; i < coveredRows.size(); i++) {
            Object theRow = rowIt.next();
            addToRow(h, theRow, colList, scores);
        }

        // Subtract minVal from all uncovered columns
        h = -minVal;
        colIt = uncoveredCols.iterator();
        for (int i = 0; i < uncoveredCols.size(); i++) {
            Object theCol = colIt.next();
            addToCol(h, theCol, rowList, scores);
        }

        mainZeroSearch(rowList, colList, scores);
    }

    // Unit test
    public static void main(String[] args) throws IllegalArgumentException {

        String x = "X";
        String y = "Y";
        String z = "Z";
        HashSet rowList = new HashSet();
        rowList.add(x);
        rowList.add(y);
        rowList.add(z);

        String a = "A";
        String b = "B";
        String c = "C";
        String d = "D";
        HashSet colList = new HashSet();
        colList.add(a);
        colList.add(b);
        colList.add(c);
        colList.add(d);

        HashMap scores = new HashMap();
        scores.put(getHashString(x, a), new Double(1));
        scores.put(getHashString(x, b), new Double(4));
        scores.put(getHashString(x, c), new Double(5));
        scores.put(getHashString(x, d), new Double(3));
        scores.put(getHashString(y, a), new Double(5));
        scores.put(getHashString(y, b), new Double(10));
        scores.put(getHashString(y, c), new Double(6));
        scores.put(getHashString(y, d), new Double(3));
        scores.put(getHashString(z, a), new Double(5));
        scores.put(getHashString(z, b), new Double(2));
        scores.put(getHashString(z, c), new Double(6));
        scores.put(getHashString(z, d), new Double(3));

        HashMap assignment = new HashMap();
        HungarianAlgorithmOrig theAlgorithm = new HungarianAlgorithmOrig();
        theAlgorithm.Solve(rowList, colList, scores, assignment);

        Iterator it = rowList.iterator();
        for (int i = 0; i < rowList.size(); i++) {
            String s = (String) it.next();
            String t = (String) assignment.get(s);
            System.out.println(s + " -> " + t);
        }

        System.exit(0);
    }
}
